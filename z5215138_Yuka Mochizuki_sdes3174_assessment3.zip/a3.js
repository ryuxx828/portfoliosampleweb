function myFunction() {
  var x = document.getElementById("hey");
  if (x.innerHTML === "こんにちは！優香と申します！私のデザインの世界へようこそ！") {
    x.innerHTML = "Hey there! I'm Yuka! Welcome to my world of design!";
  } else {
    x.innerHTML = "こんにちは！優香と申します！私のデザインの世界へようこそ！";
  }
}